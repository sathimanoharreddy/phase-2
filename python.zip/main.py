print(23+17)
print(23-17)
print(23/17)
print(23*17)
a=23
b=17
c=a+b
print(a+b)
print(c)
a=10
b=3.142
c="hello"
d=True
e=1+4j
print(a,b,c,d,e)
print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(type(e))
for i in range (2,11)
    if i%2==0:
        print("even",i)
    else:
        print("odd,i")
    


