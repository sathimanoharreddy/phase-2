#class student:
#   def __init__(self,name,rollnum,javamarks,pythonmarks,mathmarks):
#      self.name=name
#     self.rollnum=rollnum
#    self.javamarks=javamarks
#        self.pythonmarks=pythonmarks
#       self.mathmarks=mathmarks
#student=input("enter the name")
#obj =student("teja",502,68,46,79) 
#print(obj.name)
#print(obj.rollnum)
#print(obj.javamarks)
#print(obj.pythonmarks)
#print(obj.mathmarks)
#obj =student("harsha",501,67,45,78)
#print(obj.name)
#print(obj.rollnum)
#print(obj.javamarks)
#print(obj.pythonmarks)
#print(obj.mathmarks)





#class student:
#   def __init__(self,name,rollnum,javamarks,pythonmarks,mathmarks):
#        self.name=name
#        self.rollnum=rollnum
#       self.javamarks=javamarks
#        self.pythonmarks=pythonmarks
#        self.mathmarks=mathmarks
#   def printalldetails(self):
#       print(self.name)
#        print(self.rollnum)
#        print(self.javamarks)
#        print(self.pythonmarks)
#        print(self.mathmarks)
        
#obj = student("harsha",420,69,68,67)
#obj.printalldetails()

#obj2 = student("teja",421,96,97,98)
#obj2.printalldetails()

class node:
    def __init__(self,data):
        self.data=data
        self.next=None
obj1=node(10)
obj2=node(20)
obj3=node(30)
obj4=node(40)
obj5=node(50)
obj6=node(60)
obj7=node(70)
obj8=node(80)
obj9=node(90)
obj10=node(100)
obj1.next=obj2
obj2.next=obj3
obj3.next=obj4
obj4.next=obj5
obj5.next=obj6
obj6.next=obj7
obj7.next=obj8
obj8.next=obj9
obj9.next=obj10

currentnode =obj1
while currentnode !=None:
    print(currentnode.data, end=" -->")
    currentnode= currentnode.next
    


class Node:
    def __init__(self, data):
        self.data = data 
        self.next = None 
 
def printLinkedList(head):
    currentNode = head 
    while currentNode != None:
        print(currentNode.data, end = " --> ")
        currentNode = currentNode.next
    print()
 
def insertAtTail(head, ele):
    temp = Node(ele)
    if head == None:
        return temp
 
    tail = head 
    while tail.next != None:
        tail = tail.next 
    tail.next = temp 
    return head
































